import pyautogui

nw, nh = pyautogui.size()

print(nw)
print(nh)
