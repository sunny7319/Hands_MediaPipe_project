# app.py
from flask import Flask, render_template, Response
import cv2
import mediapipe as mp
import numpy as np
from classgo import Moving
from recognition_lib import util
from recognition_part import recognition

app = Flask(__name__)

# TensorFlow warning 제거
import os
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '3'
import tensorflow as tf

# Variable initialization
mp_hands = mp.solutions.hands
cap = cv2.VideoCapture(0)
cap.set(cv2.CAP_PROP_FRAME_WIDTH, 320)
cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 240)

# Load GIF files
nabi_1 = cv2.VideoCapture('outpart_lib/butterfly_1.gif')
nabi_2 = cv2.VideoCapture('outpart_lib/butterfly_3.gif')
nabi_3 = cv2.VideoCapture('outpart_lib/butterfly_4.gif')

cat_1 = cv2.VideoCapture('outpart_lib/cat_1.gif')
cat_2 = cv2.VideoCapture('outpart_lib/cat_2.gif')
cat_3 = cv2.VideoCapture('outpart_lib/cat_3.gif')

snail_1 = cv2.VideoCapture('outpart_lib/snail_1.gif')
snail_2 = cv2.VideoCapture('outpart_lib/snail_2.gif')
snail_3 = cv2.VideoCapture('outpart_lib/snail_3.gif')

deer_1 = cv2.VideoCapture('outpart_lib/deer.gif')
deer_2 = cv2.VideoCapture('outpart_lib/deer_1.gif')
deer_3 = cv2.VideoCapture('outpart_lib/deer_2.gif')

heart_1 = cv2.VideoCapture('outpart_lib/heart_1.gif')
heart_2 = cv2.VideoCapture('outpart_lib/heart_1.gif')
heart_3 = cv2.VideoCapture('outpart_lib/heart_1.gif')

duck_1 = cv2.VideoCapture('outpart_lib/duck_1.gif')
duck_2 = cv2.VideoCapture('outpart_lib/duck_2.gif')
duck_3 = cv2.VideoCapture('outpart_lib/duck_3.gif')

sun_1 = cv2.VideoCapture('outpart_lib/sun.gif')
sun_2 = cv2.VideoCapture('outpart_lib/sun.gif')
sun_3 = cv2.VideoCapture('outpart_lib/sun.gif')

house_1 = cv2.VideoCapture('outpart_lib/house.gif')
house_2 = cv2.VideoCapture('outpart_lib/house.gif')
house_3 = cv2.VideoCapture('outpart_lib/house.gif')

tree_1 = cv2.VideoCapture('outpart_lib/tree.gif')
tree_2 = cv2.VideoCapture('outpart_lib/tree.gif')
tree_3 = cv2.VideoCapture('outpart_lib/tree.gif')

rock_1 = cv2.VideoCapture('outpart_lib/rock.gif')
rock_2 = cv2.VideoCapture('outpart_lib/rock.gif')
rock_3 = cv2.VideoCapture('outpart_lib/rock.gif')

flower_1 = cv2.VideoCapture('outpart_lib/flower.gif')
flower_2 = cv2.VideoCapture('outpart_lib/flower.gif')
flower_3 = cv2.VideoCapture('outpart_lib/flower.gif')

dog_1 = cv2.VideoCapture('outpart_lib/dog_1.gif')
dog_2 = cv2.VideoCapture('outpart_lib/dog_3.gif')
dog_3 = cv2.VideoCapture('outpart_lib/dog_7.gif')

# Load background image
background = cv2.imread('outpart_lib/bg3.png')

def reset_gif(gif):
    gif.set(cv2.CAP_PROP_POS_FRAMES, 0)

def generate_frames():
    with mp_hands.Hands(static_image_mode=False, max_num_hands=6, min_detection_confidence=0.5) as hands:
        counting = 1
        dict_hand = util.make_dict_hand()
        flag = []

        while True:
            success, image = cap.read()
            if not success:
                break

            image = cv2.cvtColor(cv2.flip(image, 1), cv2.COLOR_BGR2RGB)
            results = hands.process(image)
            image = cv2.cvtColor(image, cv2.COLOR_RGB2BGR)
            nw, nh = image.shape[1], image.shape[0]

            if results.multi_hand_landmarks:
                recog = recognition(image, results.multi_hand_landmarks, dict_hand, counting)
                recog.draw_load_hand()

                if counting % 10 == 0:
                    detect_label = recog.recog_main()

                    if detect_label:
                        for i in range(0, len(detect_label)):
                            label, position = detect_label[i]
                            x_c = int(position[0] * background.shape[1])
                            y_c = int(position[1] * background.shape[0])

                            if label == 0:
                                rndN = np.random.randint(1, 4)
                                if rndN == 1:
                                    nabi = nabi_1
                                elif rndN == 2:
                                    nabi = nabi_2
                                elif rndN == 3:
                                    nabi = nabi_3
                                if (x_c + 100 > background.shape[1]) or (y_c + 100 > background.shape[0]):
                                    x_c = background.shape[1] - 100
                                    y_c = background.shape[0] - 100
                                flag.append(Moving(nabi, x_c, y_c, 100, 100, 1))

                            elif label == 1:
                                rndN = np.random.randint(1, 4)
                                if rndN == 1:
                                    cat = cat_1
                                elif rndN == 2:
                                    cat = cat_2
                                elif rndN == 3:
                                    cat = cat_3
                                if (x_c + 200 > background.shape[1]) or (y_c + 200 > background.shape[0]):
                                    x_c = background.shape[1] - 200
                                    y_c = background.shape[0] - 200
                                flag.append(Moving(cat, x_c, y_c, 200, 200, 1))

                            elif label == 2:
                                rndN = np.random.randint(1, 4)
                                if rndN == 1:
                                    snail = snail_1
                                elif rndN == 2:
                                    snail = snail_2
                                elif rndN == 3:
                                    snail = snail_3
                                if (x_c + 70 > background.shape[1]) or (y_c + 70 > background.shape[0]):
                                    x_c = background.shape[1] - 70
                                    y_c = background.shape[0] - 70
                                flag.append(Moving(snail, x_c, y_c, 70, 70, 1))

                            elif label == 3:
                                rndN = np.random.randint(1, 4)
                                if rndN == 1:
                                    deer = deer_1
                                elif rndN == 2:
                                    deer = deer_2
                                elif rndN == 3:
                                    deer = deer_3
                                if (x_c + 300 > background.shape[1]) or (y_c + 300 > background.shape[0]):
                                    x_c = background.shape[1] - 300
                                    y_c = background.shape[0] - 300
                                flag.append(Moving(deer, x_c, y_c, 300, 300, 1))

                            elif label == 4:
                                rndN = np.random.randint(1, 4)
                                if rndN == 1:
                                    heart = heart_1
                                elif rndN == 2:
                                    heart = heart_2
                                elif rndN == 3:
                                    heart = heart_3
                                if (x_c + 100 > background.shape[1]) or (y_c + 100 > background.shape[0]):
                                    x_c = background.shape[1] - 100
                                    y_c = background.shape[0] - 100
                                flag.append(Moving(heart, x_c, y_c, 100, 100, 0))

                            elif label == 5:
                                rndN = np.random.randint(1, 4)
                                if rndN == 1:
                                    duck = duck_1
                                elif rndN == 2:
                                    duck = duck_2
                                elif rndN == 3:
                                    duck = duck_3
                                if (x_c + 150 > background.shape[1]) or (y_c + 150 > background.shape[0]):
                                    x_c = background.shape[1] - 150
                                    y_c = background.shape[0] - 150
                                flag.append(Moving(duck, x_c, y_c, 150, 150, 1))

                            elif label == 6:
                                rndN = np.random.randint(1, 4)
                                if rndN == 1:
                                    sun = sun_1
                                elif rndN == 2:
                                    sun = sun_2
                                elif rndN == 3:
                                    sun = sun_3
                                if (x_c + 180 > background.shape[1]) or (y_c + 180 > background.shape[0]):
                                    x_c = background.shape[1] - 180
                                    y_c = background.shape[0] - 180
                                flag.append(Moving(sun, x_c, y_c, 180, 180, 0))

                            elif label == 7:
                                rndN = np.random.randint(1, 4)
                                if rndN == 1:
                                    house = house_1
                                elif rndN == 2:
                                    house = house_2
                                elif rndN == 3:
                                    house = house_3
                                if (x_c + 400 > background.shape[1]) or (y_c + 400 > background.shape[0]):
                                    x_c = background.shape[1] - 400
                                    y_c = background.shape[0] - 400
                                flag.append(Moving(house, x_c, y_c, 400, 400, 0))

                            elif label == 8:
                                rndN = np.random.randint(1, 4)
                                if rndN == 1:
                                    tree = tree_1
                                elif rndN == 2:
                                    tree = tree_2
                                elif rndN == 3:
                                    tree = tree_3
                                if (x_c + 350 > background.shape[1]) or (y_c + 350 > background.shape[0]):
                                    x_c = background.shape[1] - 350
                                    y_c = background.shape[0] - 350
                                flag.append(Moving(tree, x_c, y_c, 350, 350, 0))

                            elif label == 9:
                                rndN = np.random.randint(1, 4)
                                if rndN == 1:
                                    rock = rock_1
                                elif rndN == 2:
                                    rock = rock_2
                                elif rndN == 3:
                                    rock = rock_3
                                if (x_c + 120 > background.shape[1]) or (y_c + 120 > background.shape[0]):
                                    x_c = background.shape[1] - 120
                                    y_c = background.shape[0] - 120
                                flag.append(Moving(rock, x_c, y_c, 120, 120, 0))
                            # 꽃
                            elif label == 10:
                                rndN = np.random.randint(1, 4)
                                if rndN == 1:
                                    flower = flower_1
                                elif rndN == 2:
                                    flower = flower_2
                                elif rndN == 3:
                                    flower = flower_3
                                if (x_c + 70 > background.shape[1]) or (y_c + 70 > background.shape[0]):
                                    x_c = background.shape[1] - 70
                                    y_c = background.shape[0] - 70
                                flag.append(Moving(flower, x_c, y_c, 70, 70, 0))
                                            
                            elif label == 11:
                                rndN = np.random.randint(1, 4)
                                if rndN == 1:
                                    dog = dog_1
                                elif rndN == 2:
                                    dog = dog_2
                                elif rndN == 3:
                                    dog = dog_3
                                if (x_c + 100 > background.shape[1]) or (y_c + 100 > background.shape[0]):
                                    x_c = background.shape[1] - 100
                                    y_c = background.shape[0] - 100
                                flag.append(Moving(dog, x_c, y_c, 100, 100, 1))

            counting += 1

            frame_with_background = background.copy()

            for obj in flag:
                frame = obj.gif.read()[1]
                if frame is not None and frame.size != 0:
                    obj.frame = cv2.resize(frame, (obj.resize_x, obj.resize_y))
                    if obj.way == 1:
                        obj.frame = cv2.flip(obj.frame, 1)
                    frame_with_background[obj.rp[obj.c][1]:obj.rp[obj.c][1] + obj.frame.shape[0],
                                          obj.rp[obj.c][0]:obj.rp[obj.c][0] + obj.frame.shape[1]] = obj.frame
                reset_gif(obj.gif)

            webcam_x_offset, webcam_y_offset = 10, 10
            frame_with_background[webcam_y_offset:webcam_y_offset + nh,
                                  webcam_x_offset:webcam_x_offset + nw] = image

            ret, buffer = cv2.imencode('.jpg', frame_with_background)
            frame = buffer.tobytes()
            yield (b'--frame\r\n'
                   b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n')

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/video_feed')
def video_feed():
    return Response(generate_frames(), mimetype='multipart/x-mixed-replace; boundary=frame')

if __name__ == '__main__':
    app.run(debug=True)