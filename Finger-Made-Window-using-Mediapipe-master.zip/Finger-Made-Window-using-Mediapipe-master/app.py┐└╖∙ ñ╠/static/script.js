const videoElement = document.getElementById('webcam');
const canvasElement = document.getElementById('overlay');
const canvasCtx = canvasElement.getContext('2d');

// In this example, we are not using MediaPipe Hands on the client-side.
// However, you can add client-side processing if needed.

function drawGif(x, y, gif) {
    const img = new Image();
    img.src = gif;
    img.onload = () => {
        canvasCtx.drawImage(img, x, y, 100, 100); // Adjust size as needed
    };
}

// Example to draw a GIF at a specific position
drawGif(100, 100, '/static/your_gif_file.gif');
